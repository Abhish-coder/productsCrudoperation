package com.example.crudoperationondb.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.crudoperationondb.model.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

	

	// S save(Product product);

}
