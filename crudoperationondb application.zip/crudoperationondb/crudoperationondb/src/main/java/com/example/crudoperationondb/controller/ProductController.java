package com.example.crudoperationondb.controller;



import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.crudoperationondb.exception.ProductNotFoundException;
import com.example.crudoperationondb.model.Product;
import com.example.crudoperationondb.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productservice;

	/*
	 * @GetMapping("/products") public List<Product> getAllProducts(){
	 * 
	 * return Arrays.asList( new Product("P101","Pen","School"), new
	 * Product("P102","laptop","electronics"), new
	 * Product("P103","fan","electronics"));
	 * 
	 * }
	 */
	@GetMapping("/products")
	public List<Product> getAllData() {
		return productservice.getAllProducts();
	}

	@GetMapping("/products/{pId}")
	public Product getProduct(@PathVariable("pId") Long id) {

		return productservice.getProduct(id).orElseThrow(() -> new ProductNotFoundException(id));

	}

	@PostMapping("/products")
	public void addproductdetails(@RequestBody Product product) {

		productservice.addProduct(product);
	}

	@PutMapping("/products/{pId}")
	public void updateProduct(@RequestBody Product product, @PathVariable("pId") Long id) {

		productservice.updateProduct(id, product);

	}

	@DeleteMapping("/products/{pId}")
	public void deleteproduct(@PathVariable("pId") Long id) {

		productservice.deleteproduct(id);

	}
}
