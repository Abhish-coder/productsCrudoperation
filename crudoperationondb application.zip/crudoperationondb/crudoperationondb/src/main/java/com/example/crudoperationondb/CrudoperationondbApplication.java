package com.example.crudoperationondb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import com.example.crudoperationondb.model.Product;
import com.example.crudoperationondb.repository.ProductRepository;

@SpringBootApplication
@EnableCaching
public class CrudoperationondbApplication implements CommandLineRunner {

	@Autowired
	private ProductRepository productRepository;

	public static void main(String[] args) {
		SpringApplication.run(CrudoperationondbApplication.class, args);
	}

	@Override
	public void run(String... strings) throws Exception {

		productRepository.save(new Product("Television", "Electronics"));
		productRepository.save(new Product("Air conditioner", "Electronics"));
		productRepository.save(new Product("sofa", "furniture"));
	}

}


